create procedure WLUserManage(INOUT userId     int, INOUT adminName varchar(20), INOUT adminSex enum ('男'),
  INOUT                             adminState varchar(20), INOUT adminCity varchar(20), INOUT adminAddress varchar(20),
  INOUT                             adminPwd   varchar(20), INOUT adminTel varchar(20), INOUT commEnd text)
  begin
    select * from admin; -- 查看管理员
    delete from admin where admin_id;
    insert into admin(user_id,admin_name,admin_sex,admin_state,admin_city,admin_address,admin_pwd,admin_tel,commend)
    values(userId,adminName,adminSex,adminState,adminCity,adminAddress,adminPwd,adminTel,commEnd); -- 添加管理员
    select * from admin;
  end;

