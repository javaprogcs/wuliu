create procedure WLDeliverRange(INOUT delName        varchar(20), INOUT peisongPrice decimal, INOUT delCityId int,
  INOUT                               peisongComment varchar(20))
  begin
      select del_city_id from deliverymethod where del_city_id =delCityId; -- 查询配送区域
      insert into deliverymethod(del_name,peisong_price,del_city_id,peisong_comment) values(delName,peiSongPrice,delCityId,peisongComment); -- 添加配送区域
     update  deliverymethod set del_name = delName and peisong_price = peisongPrice and del_city_id = delCityId and peisong_comment = peisongComment; -- 修改信息
      select * from deliverymethod; -- 查看信息
      delete from deliverymethod where del_city_id =delCityId; -- 删除配送区域
  end;

