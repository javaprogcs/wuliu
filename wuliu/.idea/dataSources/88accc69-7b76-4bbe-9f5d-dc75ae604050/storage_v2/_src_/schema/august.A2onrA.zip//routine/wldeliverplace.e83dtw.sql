create procedure WLDeliverPlace(INOUT peiProvinceId      int, INOUT peiCityId int, INOUT adminId int,
  INOUT                               peisongdianName    varchar(20), INOUT peisongdianTel varchar(20),
  INOUT                               peisongdianAddress varchar(20), INOUT peisongdianComment text)
  begin
    select * from peisongdian; -- 查询配送点
    insert into peisongdian(pei_province_id,pei_city_id,admin_id,peisongdian_name,peisongdian_tel,peisongdian_address,peisongdian_comment) -- 添加配送点
    values(peiProvinceId,peiCityId,adminId,peisongdianName,peisongdianTel,peisongdianAddress,peisongdianComment); -- 添加配送点
    select * from peisongdian; -- 查看配送点信息
   update  peisongdian set  pei_province_id = peiProvinceId and pei_city_id = peiCityId and admin_id = adminId and peisongdian_name = peisongdianName and peisongdian_tel = peisongdianTel and peisongdian_address = peisongdianAddress
    and peisongdian_comment = peisongdianComment; -- 修改信息
  --  delete from set peisongdian_id; -- 删除配送点
  end;

