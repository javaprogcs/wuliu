create procedure WLBus(INOUT routeId        int, INOUT vehicleType varchar(20), INOUT yiel_dly varchar(20),
  INOUT                      productionDate datetime, INOUT buyDate datetime, INOUT vehicleComment varchar(20))
  begin
    insert into vehicle(route_id, vehicle_type, yieldly, production_date, buy_date, vehicle_comment) values(routeId,vehicleType,yiel_dly,productionDate,buyDate,vehicleComment); -- 添加车辆
    update vehicle set route_id =routeId and vehicle_type=vehicleType and yieldly=yiel_dly and production_date=productionDate and buy_date=buyDate and vehicle_comment=vehicleComment; -- 修改车辆
    select * from vehicle; -- 查看车辆信息
    delete from vehicle where route_id =routeId; -- 删除车辆
  end;

