create procedure WLReport(INOUT routeNmae             varchar(20), INOUT startDistrictId int, INOUT startCityId int,
  INOUT                         midpointDistrictId    varchar(20), INOUT midpointCityId varchar(20),
  INOUT                         destinationDistrictId varchar(20), INOUT destinationCityId varchar(20),
  INOUT                         carriagePrice         decimal, INOUT routeComment text)
  begin
      select * from route; -- 查询路线
      insert into route(route_name,start_district_id,start_city_id,midpoint_district_id,midpoint_city_id,destination_district_id,destination_city_id,carriage_price,route_comment)
      value(routeNmae,startDistrictId,startCityId,midpointDistrictId,midpointCityId,destinationDistrictId,destinationCityId,carriagePrice,routeComment); -- 添加路线
  end;

