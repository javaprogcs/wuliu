create procedure WLCheckInfo(INOUT custpwd varchar(20), INOUT peiCityId varchar(20))
  begin
    select * from customer; -- 登录信息检验
    select * from customer where cust_pwd = custpwd; -- 密码检验
    update  customer set cust_pwd = custpwd; -- 修改密码
    select * from peisongdian where  pei_city_id = peiCityId; -- 配送区域检验
  end;

