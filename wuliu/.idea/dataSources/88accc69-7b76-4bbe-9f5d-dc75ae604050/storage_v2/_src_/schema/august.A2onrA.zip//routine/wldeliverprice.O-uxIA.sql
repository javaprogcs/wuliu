create procedure WLDeliverPrice(INOUT peisongPrice decimal)
  begin
    select peisong_price from deliverymethod where peisong_price = peisongPrice; -- 查看配送价格

  end;

