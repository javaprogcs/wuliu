create procedure WLCommonSearch(INOUT peiCityId int)
  begin
    select * from province; -- 获取所有省份
    select * from city ; -- 获取所有城市
    select * from admin ; -- 获取所有管理员
    select * from peisongdian; -- 获取所有配送点
    select * from peisongdian where pei_city_id = peiCityId; -- 获取所有配送区域
    select Max(total_price) from  aug_order;-- 获取最大价格
    select min(total_price) from aug_order; -- 获取最小价格
    select * from aug_order where delivery_price; -- 获取所有配送价格
    select * from route; -- 获取所有配送路线
    select * from vehicle; -- 获取所有车辆
    select * from delivery; -- 获取所有交接单
  end;

